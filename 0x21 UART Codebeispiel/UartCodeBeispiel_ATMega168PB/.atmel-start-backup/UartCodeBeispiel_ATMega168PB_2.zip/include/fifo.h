/*
 * fifo.h
 *
 * Created: 12.08.2018 12:25:18
 *  Author: kurjon
 */ 


#ifndef FIFO_H_
#define FIFO_H_

enum eFifoIndex {
	FIFO_UART_TX = 0,
	FIFO_UART_RX,
	NUMBER_OF_FIFOS  // do not use this as index
};

void	fifoWrite(eFifoIndex idx, uint8_t din);
uint8_t fifoRead(eFifoIndex idx);
uint8_t cleanUpFifo(eFifoIndex fifo);

#endif /* FIFO_H_ */