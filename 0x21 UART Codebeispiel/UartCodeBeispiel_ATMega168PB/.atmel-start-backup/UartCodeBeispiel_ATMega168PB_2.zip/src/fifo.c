/*
 * Fifo.c
 *
 * Created: 12.08.2018 12:24:44
 *  Author: kurjon
 */ 

#define BLEN (16)
#define BMSK (BLEN-1)

typedef struct {
	volatile unsigned char w;
	volatile unsigned char r;
	unsigned char d[BLEN];  // die Daten sind nicht volatil, sie k�nnen sich
} fifo_t;                 // nur ge�ndert haben, wenn der Index sich �ndert

fifo_t fifo[NUMBER_OF_FIFOS];


void fifoWrite(eFifoIndex idx, uint8_t din){
	
	if (fifo[idx].w != fifo[idx]) {
		// set tx data empty flag
	}
	
	// Fifo schreiben
	if ((fifo[idx].w - fifo[idx].r) & BMSK == BMSK) {
		// Fehlerbehandlung: Fifo ist voll
	}
	else {
		// Zeichen eintragen
		fifo[idx].d[fifo[idx].w & BMSK] = din;
		fifo[idx].w++;
	}
	
	if ()
}

uint8_t fifoRead(eFifoIndex idx){
	uint8_t dout;
	
	// Fifo lesen
	if (fifo[idx].w != fifo[idx].r) { // Fifo belegt?
		// Zeichen auslesen
		dout = fifo[idx].d[fifo[idx].r&BMSK];
		fifo[idx].r++;
	}
	
	return dout;
}

bool fifoEmpty(eFifoIndex idx){	
	
	if (fifo[idx].w != fifo[idx].r) { // Fifo belegt?
		return false;
	}
	
	return true;
}

uint8_t cleanUpFifo(eFifoIndex idx){
	fifo[idx].w = fifo[idx].r;
}
