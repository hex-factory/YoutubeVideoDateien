#include <atmel_start.h>

#include "fifo.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	fifoWrite(FIFO_UART_TX, 'h');
	fifoWrite(FIFO_UART_TX, 'e');
	fifoWrite(FIFO_UART_TX, 'l');
	fifoWrite(FIFO_UART_TX, 'l');
	
	/* Replace with your application code */
	while (1) {
		

	}
}
